package chap08;

import javax.swing.*;

public class ContentPanelEx extends JFrame {


}
