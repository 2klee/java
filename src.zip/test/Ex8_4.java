package test;

import javax.swing.*;
import java.awt.*;

public class Ex8_4 extends JFrame {
  public Ex8_4(){
    super("p.340 예제 8-4");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Container c = getContentPane();
    c.setLayout(new FlowLayout());

  }

}
