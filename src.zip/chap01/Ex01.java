package sec03_1.chap01;

public class Ex01 {
  public static void main(String[] args) {
    byte _1b_byte = 1;
    short _2b_short = 2;
    int _4b_int = 3;
    long _8b_long = 4;


//    byte overByte1 = 127;
//    byte overByte2 = 128;
//    byte overByte3 = -128;
//    byte overByte4 = -129;


    _2b_short = _1b_byte;



    int _4b_int2 = 123_456_789;
    long _8b_long2 = 123_456_789_123_456_789L;

  }
}
