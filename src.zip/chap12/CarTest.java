//package chap12;
//
//class Car {
//  String name;
//
//  public Car(){}
//
//  public CarTest(String name) {
//    this.name = name;
//  }
//}
//
//// 아래의 결과가 true true false 가 나오도록
//// HashMap을 사용하여 CarFactory 클래스를 구현해보세요.
//
//public class CarTest {
//  public static void main(String[] args) {
//    CarFactory = factory = CarFactory.getInstance();
//    Car sonata1 = factory.createCar("연수 차");
//    Car sonata2 = factory.createCar("연수 차");
//    System.out.println(sonata1 == sonata2); // true
//
//    Car avante1 = factory.createCar("승연 차");
//    Car avante2 = factory.createCar("승연 차");
//    System.out.println(avante1 == avante2); // true
//    System.out.println(avante1 == avante1); // false
//
//  }
//
//
//}
