//package Exam.chap07;
//
//import chap12.generics.Point;
//
//import java.util.ArrayList;
//import java.util.Scanner;
//
//public class Location {
//  static int x;
//  static int y;
//  public void Point(int x, int y) {
//    this.x = x;
//    this.y = y;
//  }
//
//
//
//  public static void main(String[] args) {
//    ArrayList<Point> pList = new ArrayList<>();
//    Scanner sc = new Scanner(System.in);
//
//    Point
//
//    System.out.println("쥐가 이동한 위치(x, y)를 5개 입력하라.");
//    x = sc.nextInt();
//    y = sc.nextInt();
//
//    System.out.println();
//
//
//
//
//
//
////    while (true){
////      System.out.print(">> ");
////
////
////    }
//  }
//}
