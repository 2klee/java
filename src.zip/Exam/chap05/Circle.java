package Exam.chap05;

class Circle {
  private int radious;
  public Circle(){
    this.radious = radious;
  }
  public int getRadious(){
    return radious;
  }
}
