package sec03.chap05;

 class Adder extends Calculator1 {


  @Override
  protected int calc() {
    return a + b;
  }
}
