//package sec03.chap05;
//
//public class Animal {
//
//  // 매소드 선언
//  public void breathe(){
//    System.out.println("숨을 쉰다");
//  }
//
//  // 추상매소드 선언
//  public abstract void sound();
//}
