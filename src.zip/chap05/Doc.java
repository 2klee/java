//package sec03.chap05;
//
//public class Doc extends Animal {
//
//  @Override
//  public void sound(){
//    System.out.println("멍멍");
//  }
//
//}
