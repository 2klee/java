package sec03.chap05;

// p.221 예제 5-5

abstract class Calculator {

  public abstract int add(int a, int b);
  public abstract int subtract(int a, int b);
  public abstract double average(int[] a);

}
