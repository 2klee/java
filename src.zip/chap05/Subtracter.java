package sec03.chap05;

public class Subtracter extends Calculator1 {


  @Override
  protected int calc() {
    return a - b;
  }
}
