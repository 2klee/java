//package sec03.chap05;
//
//public class AbstractExam {
//  public static void main(String[] args) {
//    Doc doc = new Doc();
//    doc.sound();
//
//
//    Cat cat = new Cat();
//    cat.sound();
//
//    animalSound(new Doc());
//    animalSound(new Cat());
//
//
//  }
//
//  public static void animalSound(Animal animal){
//    animal.sound();
//  }
//}
