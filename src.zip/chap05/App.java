package sec03.chap05;

public class App {
  public static void main(String[] args) {
    Adder adder = new Adder();
    Subtracter sub = new Subtracter();

    adder.run();
    sub.run();
  }
}
