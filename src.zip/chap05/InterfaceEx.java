package sec03.chap05;

public class InterfaceEx {
  public static void main(String[] args) {
    SamsungPhone phone = new SamsungPhone();
    phone.printLogo();
    phone.sendCall();
    phone.receiveCall();
    phone.flash();
  }
}
