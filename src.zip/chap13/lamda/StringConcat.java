package chap13.lamda;

public interface StringConcat {
  public void makeString(String s1, String s2);

}
