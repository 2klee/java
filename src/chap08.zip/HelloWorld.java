package chap08;

import javax.swing.*;

public class HelloWorld {
  public static void main(String[] args) {

    JFrame mainFrame = new JFrame();

    mainFrame.setSize(800,600);

    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    mainFrame.setVisible(true);

    mainFrame.setTitle("rkskekf");

    mainFrame.setLocation(500,300);
  }
}
