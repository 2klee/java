package chap12.generics;

public class ThreeDPrinter {
	//재료가 파우더인 경우
	private Object material;

	public void setMaterial(Object material){
		this.material = material;
	}

	public Object getMaterial(){
		return material;
	}

//	private Object material;
//
//	public void setMaterial(Object material) {
//		this.material = material;
//	}
//
//	public Object getMaterial() {
//		return material;
//	}
}
